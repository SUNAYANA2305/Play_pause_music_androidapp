package com.example.block04;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    //the mp3 file is icorporated in to application using MediaPlayer class from android api
    MediaPlayer myMusic; //object



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myMusic = MediaPlayer.create(this, R.raw.music1); //creating object for music file
        Switch switch_loop = (Switch) findViewById(R.id.switch_loop);
        switch_loop.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                myMusic.setLooping(isChecked);
            }
        });
    }
    public void playMusic (View v){
        myMusic.start();

    }
    public void pauseMusic (View v){
        if(myMusic.isPlaying())
            myMusic.pause();
        
    }
}